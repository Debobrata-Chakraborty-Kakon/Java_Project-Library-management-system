package interfaces;

import java.lang.*;
import entity.*;

public interface IIssueRepo
{
	public void issue(Issue i);


}

